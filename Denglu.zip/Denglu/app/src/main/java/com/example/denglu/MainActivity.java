package com.example.denglu;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void register(View v){

        EditText nameEdt=findViewById(R.id.name);
        EditText pwdEdt=findViewById(R.id.pwd);
        final ProgressBar proBar=findViewById(R.id.pro_bar);

        String name=nameEdt.getText().toString();
        String pwd=pwdEdt.getText().toString();
        if (name.equals("")||pwd.equals("")){
            Toast.makeText(this,"姓名或者密码不为空",Toast.LENGTH_SHORT).show();
        }else {
            proBar.setVisibility(View.VISIBLE);
            new Thread(){
                @Override
                public void run(){
                    for (int i=0;i<=100;i++){
                        proBar.setProgress(i);
                        try {
                            Thread.sleep(30);
                        }catch (InterruptedException e){
                            e.printStackTrace();
                        }
                    }
                }
            }.start();
        }


    }
}
